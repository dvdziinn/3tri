
let titulo = document.querySelector (".titulo");
console.log (titulo.textContent);
titulo.textContent = "fica grande";

let paciente = document.querySelector ("#primeiro_paciente");
console.log (paciente);

let tdPeso = paciente.querySelector(".info-peso");
console.log(tdPeso);
let peso = tdPeso.textContent;

let tdAltura = paciente.querySelector(".info-altura");
console.log(tdAltura);
let altura = tdAltura.textContent;

let imc = peso / (altura*altura);
console.log(imc)
let tdImc = paciente.querySelector(".info-imc");
tdImc.textContent = imc;

let pesoEhValido = true;
let alturaEhValida = true;

if (peso <= 0|| peso >=1000) {
    tdImc.textContent = "Peso inválido";
    pesoEhValido = false;
}

if(altura <= 0 || altura >= 3){
    tdImc.textContent = "Altura inválida";
    alturaEhValida = false; 
}
if(pesoEhValido && alturaEhValida){
    let imc = peso/ (altura*altura);
}
