
let titulo = document.querySelector (".titulo");
console.log (titulo.textContent);
titulo.textContent = "fica grande";
let paciente = document.querySelector ("#primeiro_paciente");
console.log (paciente);

let tdPeso = paciente.querySelector(".info-peso");
console.log(tdPeso);
let peso = tdPeso.textContent;

let tdAltura = paciente.querySelector(".info-altura");
console.log(tdAltura);
let altura = tdAltura.textContent;

let imc = peso / (altura*altura);
console.log(imc)
let tdImc = paciente.querySelector(".info-imc");
tdImc.textContent = imc;

if (peso <= 0|| peso >=1000) {
    console.log("Peso invalido!"); 
}

